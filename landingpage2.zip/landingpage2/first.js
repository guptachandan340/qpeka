function add()
{
a=5
b=25
c=a+b
alert(c)
}